# CodSoft Internship - Task 3: Movie Recommendation System

**Intern Name:** HARSH  
**Company:** CodSoft  
**Domain:** Artificial Intelligence / Java Programming  
**Task:** Task 3 — Recommendation System

---

## 📌 Task Description

Create a simple recommendation system that suggests items to users based on their
preferences. This implementation uses **content-based filtering** — comparing the
descriptions of movies via the **Jaccard similarity** of their summary keywords —
to recommend films similar to one the user already enjoys.

See [`assets/task.png`](assets/task.png) for the official task description.

---

## 🚀 Features

- Built-in movie dataset with short keyword-rich summaries
- Content-based similarity using the Jaccard index of summary words
- Returns the top-3 most similar movies to the user's input
- Case-insensitive movie lookup
- Clean, dependency-free Java implementation

---

## 🛠️ Tech Stack

- **Language:** Java
- **Technique:** Content-Based Filtering (Jaccard Similarity)
- **Tools:** JDK 8+, any terminal / IDE

---

## ▶️ How to Run

1. Ensure Java (JDK 8 or higher) is installed:
   ```bash
   java -version
   ```
2. Clone this repository:
   ```bash
   git clone https://github.com/<your-username>/CodSoft-Task3-MovieRecommender.git
   cd CodSoft-Task3-MovieRecommender
   ```
3. Compile and run:
   ```bash
   cd src
   javac MovieRecommender.java
   java MovieRecommender
   ```

---

## 🎬 Sample Run

```
Enter a movie you liked: Interstellar

You might also enjoy:
Inception
The Prestige
The Matrix
```

## 📚 Available Movies

- Interstellar
- The Prestige
- The Dark Knight
- The Matrix
- Inception
- Titanic

---

## 🧠 How the Similarity Works

For two movie summaries, each is split into a set of unique words. The similarity
score is:

```
similarity = |A ∩ B| / |A ∪ B|
```

Higher scores mean the summaries share more descriptive keywords, indicating
similar themes.

---

## 📂 Project Structure

```
CodSoft-Task3-MovieRecommender/
├── src/
│   └── MovieRecommender.java
├── assets/
│   └── task.png
├── .gitignore
├── LICENSE
└── README.md
```

---

## 🙌 Acknowledgement

Thanks to **CodSoft** for this internship opportunity to build practical projects
and strengthen my programming skills.

## 📬 Contact

**HARSH** — CodSoft Intern
