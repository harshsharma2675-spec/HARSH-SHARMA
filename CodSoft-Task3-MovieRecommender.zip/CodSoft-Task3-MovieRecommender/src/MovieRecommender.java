import java.util.*;

public class MovieRecommender {

    static class Film {
        String name;
        String summary;

        Film(String name, String summary) {
            this.name = name;
            this.summary = summary.toLowerCase();
        }
    }

    // Compare two summaries and return similarity score
    public static double findSimilarity(String text1, String text2) {
        String[] wordsA = text1.split("\\s+");
        String[] wordsB = text2.split("\\s+");

        Set<String> setA = new HashSet<>(Arrays.asList(wordsA));
        Set<String> setB = new HashSet<>(Arrays.asList(wordsB));

        Set<String> intersection = new HashSet<>(setA);
        intersection.retainAll(setB);

        Set<String> union = new HashSet<>(setA);
        union.addAll(setB);

        if (union.isEmpty()) return 0.0;
        return (double) intersection.size() / union.size();
    }

    public static void main(String[] args) {
        List<Film> films = new ArrayList<>();

        films.add(new Film("Interstellar",
            "A team of explorers travel through a wormhole in space time travel survival humanity gravity black hole"));
        films.add(new Film("The Prestige",
            "Two stage magicians engage in a battle to create the ultimate illusion rivalry obsession science mystery"));
        films.add(new Film("The Dark Knight",
            "Batman battles the Joker in Gotham City crime justice chaos hero sacrifice"));
        films.add(new Film("The Matrix",
            "A computer hacker learns about the true nature of reality simulation rebellion technology fight"));
        films.add(new Film("Inception",
            "A thief who steals corporate secrets through dream sharing technology is given a chance at redemption gravity dream travel"));
        films.add(new Film("Titanic",
            "A love story unfolds aboard the ill fated luxury liner ship romance tragedy disaster"));

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a movie you liked: ");
        String input = scanner.nextLine().trim();

        Film target = null;
        for (Film f : films) {
            if (f.name.equalsIgnoreCase(input)) {
                target = f;
                break;
            }
        }

        if (target == null) {
            System.out.println("Movie not found in database.");
            return;
        }

        Map<Film, Double> scores = new HashMap<>();
        for (Film f : films) {
            if (f != target) {
                scores.put(f, findSimilarity(target.summary, f.summary));
            }
        }

        List<Map.Entry<Film, Double>> sorted = new ArrayList<>(scores.entrySet());
        sorted.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));

        System.out.println("\nYou might also enjoy:");
        int count = 0;
        for (Map.Entry<Film, Double> entry : sorted) {
            if (count >= 3) break;
            System.out.println(entry.getKey().name);
            count++;
        }
    }
}
