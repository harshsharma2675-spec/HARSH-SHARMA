# CodSoft Internship - Task 1: Rule-Based Chatbot

**Intern Name:** HARSH  
**Company:** CodSoft  
**Domain:** Artificial Intelligence / Java Programming  
**Task:** Task 1 — Rule-Based Chatbot

---

## 📌 Task Description

Build a simple rule-based chatbot that responds to user inputs based on predefined
rules. Use `if-else` statements or pattern matching techniques to identify user
queries and provide appropriate responses. This task gives hands-on experience
with natural language processing basics and conversation flow.

See [`assets/task.png`](assets/task.png) for the official task description.

---

## 🚀 Features

- Interactive command-line chat interface
- Recognises greetings (`hello`, `hi`)
- Answers common questions (`how are you`, `your name`)
- Graceful exit with the `exit` command
- Fallback response for unrecognised input

---

## 🛠️ Tech Stack

- **Language:** Java
- **Tools:** JDK 8+, any terminal / IDE (IntelliJ, VS Code, Eclipse)

---

## ▶️ How to Run

1. Make sure Java (JDK 8 or higher) is installed:
   ```bash
   java -version
   ```
2. Clone this repository:
   ```bash
   git clone https://github.com/<your-username>/CodSoft-Task1-Chatbot.git
   cd CodSoft-Task1-Chatbot
   ```
3. Compile and run:
   ```bash
   cd src
   javac Chatbot.java
   java Chatbot
   ```

---

## 💬 Sample Conversation

```
🤖 ChatBot: Hello! I'm your simple rule-based chatbot.
Type 'exit' to end the chat.

You: hi
🤖 ChatBot: Hi there! How can I assist you today?
You: how are you
🤖 ChatBot: I'm just code, but I'm doing great! 😄
You: what is your name
🤖 ChatBot: I'm ChatBot, your virtual assistant!
You: exit
🤖 ChatBot: Goodbye! Take care.
```

---

## 📂 Project Structure

```
CodSoft-Task1-Chatbot/
├── src/
│   └── Chatbot.java
├── assets/
│   └── task.png
├── .gitignore
├── LICENSE
└── README.md
```

---

## 🙌 Acknowledgement

Thanks to **CodSoft** for this internship opportunity to build practical projects
and strengthen my programming skills.

## 📬 Contact

**HARSH** — CodSoft Intern  
Feel free to connect on LinkedIn and check out the rest of the internship tasks!
