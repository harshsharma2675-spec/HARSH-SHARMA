import java.util.Scanner;

public class TicTacToeAI {
    static char[] board = {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '};
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Welcome to Tic-Tac-Toe!");
        System.out.println("You are X, AI is O.");
        printBoard();

        while (true) {
            playerMove();
            printBoard();
            if (isWinner('X')) {
                System.out.println("Congratulations! You win!");
                break;
            }
            if (isDraw()) {
                System.out.println("It's a draw!");
                break;
            }

            aiMove();
            printBoard();
            if (isWinner('O')) {
                System.out.println("AI wins! Better luck next time.");
                break;
            }
            if (isDraw()) {
                System.out.println("It's a draw!");
                break;
            }
        }
    }

    static void printBoard() {
        System.out.println();
        for (int i = 0; i < 9; i += 3) {
            System.out.println(" " + board[i] + " | " + board[i + 1] + " | " + board[i + 2] + " ");
            if (i < 6) System.out.println("---+---+---");
        }
        System.out.println();
    }

    static void playerMove() {
        int move;
        while (true) {
            System.out.print("Enter your move (1-9): ");
            move = Integer.parseInt(scanner.nextLine().trim()) - 1;
            if (move >= 0 && move < 9 && board[move] == ' ') {
                board[move] = 'X';
                break;
            } else {
                System.out.println("Invalid move. Try again.");
            }
        }
    }

    static void aiMove() {
        System.out.println("AI is making a move...");

        // 1. Try to win
        int move = findWinningMove('O');
        // 2. Else block player from winning
        if (move == -1) move = findWinningMove('X');
        // 3. Else take center if free
        if (move == -1 && board[4] == ' ') move = 4;
        // 4. Else pick random empty spot
        if (move == -1) {
            java.util.List<Integer> empty = new java.util.ArrayList<>();
            for (int i = 0; i < 9; i++) if (board[i] == ' ') empty.add(i);
            move = empty.get(new java.util.Random().nextInt(empty.size()));
        }

        board[move] = 'O';
    }

    static int findWinningMove(char player) {
        int[][] wins = {
            {0,1,2}, {3,4,5}, {6,7,8},
            {0,3,6}, {1,4,7}, {2,5,8},
            {0,4,8}, {2,4,6}
        };
        for (int[] line : wins) {
            int a = line[0], b = line[1], c = line[2];
            char[] vals = {board[a], board[b], board[c]};
            int emptyCount = 0, emptyIdx = -1, playerCount = 0;
            for (int i = 0; i < 3; i++) {
                if (vals[i] == ' ') { emptyCount++; emptyIdx = line[i]; }
                else if (vals[i] == player) playerCount++;
            }
            if (playerCount == 2 && emptyCount == 1) return emptyIdx;
        }
        return -1;
    }

    static boolean isWinner(char player) {
        int[][] wins = {
            {0,1,2}, {3,4,5}, {6,7,8},
            {0,3,6}, {1,4,7}, {2,5,8},
            {0,4,8}, {2,4,6}
        };
        for (int[] line : wins) {
            if (board[line[0]] == player && board[line[1]] == player && board[line[2]] == player) {
                return true;
            }
        }
        return false;
    }

    static boolean isDraw() {
        for (char c : board) {
            if (c == ' ') return false;
        }
        return true;
    }
}
