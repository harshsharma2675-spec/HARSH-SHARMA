# CodSoft Internship - Task 2: Tic-Tac-Toe AI

**Intern Name:** HARSH  
**Company:** CodSoft  
**Domain:** Artificial Intelligence / Java Programming  
**Task:** Task 2 — Tic-Tac-Toe AI

---

## 📌 Task Description

Implement an AI agent that plays the classic game of Tic-Tac-Toe against a human
player. Use a rule-based strategy (win → block → center → random) to make the AI
unbeatable in most scenarios. This project explores basic game theory and
decision-making algorithms.

See [`assets/task.png`](assets/task.png) for the official task description.

---

## 🚀 Features

- Play Tic-Tac-Toe (X) against an AI (O) in the terminal
- AI decision logic:
  1. Take a winning move if available
  2. Block the player's winning move
  3. Take the center square if free
  4. Otherwise, pick a random empty cell
- Detects wins and draws automatically
- Simple, clean board rendering

---

## 🛠️ Tech Stack

- **Language:** Java
- **Tools:** JDK 8+, any terminal / IDE

---

## ▶️ How to Run

1. Ensure Java (JDK 8 or higher) is installed:
   ```bash
   java -version
   ```
2. Clone this repository:
   ```bash
   git clone https://github.com/<your-username>/CodSoft-Task2-TicTacToeAI.git
   cd CodSoft-Task2-TicTacToeAI
   ```
3. Compile and run:
   ```bash
   cd src
   javac TicTacToeAI.java
   java TicTacToeAI
   ```

---

## 🎮 Board Positions

Cells are numbered 1–9 as shown:

```
 1 | 2 | 3
---+---+---
 4 | 5 | 6
---+---+---
 7 | 8 | 9
```

---

## 📂 Project Structure

```
CodSoft-Task2-TicTacToeAI/
├── src/
│   └── TicTacToeAI.java
├── assets/
│   └── task.png
├── .gitignore
├── LICENSE
└── README.md
```

---

## 🙌 Acknowledgement

Thanks to **CodSoft** for this internship opportunity to build practical projects
and strengthen my programming skills.

## 📬 Contact

**HARSH** — CodSoft Intern
